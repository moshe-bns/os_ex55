#include "VirtualMemory.h"
#include "PhysicalMemory.h"
#include <algorithm>


void clearTable(uint64_t frameIndex) {
    for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
        PMwrite(frameIndex * PAGE_SIZE + i, 0);
    }
}

int min_ours(int a, int b){
    if (a>b){
        return b;
    }
    return a;
}

void VMinitialize() {
    clearTable(0);
}

uint64_t get_offset(uint64_t virtualAddress){
    return virtualAddress & (uint64_t)((1LL<<OFFSET_WIDTH)-1);
}

uint64_t get_index(uint64_t virtualAddress){
    return (virtualAddress & ~((uint64_t)((1LL<<OFFSET_WIDTH)-1))) >> OFFSET_WIDTH;
}

uint64_t get_left_table(uint64_t index, int num_of_bits_in_index){
    if(!(num_of_bits_in_index% OFFSET_WIDTH)){
        return index >> (num_of_bits_in_index -OFFSET_WIDTH);
    }
    return index >> (num_of_bits_in_index-num_of_bits_in_index%OFFSET_WIDTH);
}

uint64_t get_remain_table(uint64_t index, int num_of_bits_in_index){
    if(!(num_of_bits_in_index% OFFSET_WIDTH)){
        return index & ((1LL << (num_of_bits_in_index- OFFSET_WIDTH)) -1);
    }
    return index & ((1LL << (num_of_bits_in_index -(num_of_bits_in_index%OFFSET_WIDTH)))-1);
}


uint64_t dfs(uint64_t root, uint64_t curr_father, uint64_t * max_frame_p_case2, uint64_t page_swapped_in,
             uint64_t * max_cyclic_distance, uint64_t * max_frame_father, uint64_t * max_frame_cur,
             uint64_t moving_father, uint64_t p, uint64_t *max_p, uint64_t depth){
    if(*max_frame_p_case2<root){
        *max_frame_p_case2=root;
    }
    if(!depth){
        uint64_t min_value = (uint64_t)min_ours ((int)NUM_PAGES-abs((int)page_swapped_in-(int)p),abs((int)page_swapped_in-(int)p));
        if (min_value>*max_cyclic_distance){
            *max_cyclic_distance = min_value;
            *max_frame_father= moving_father;
            *max_frame_cur = root;
            *max_p=p;
        }
        return 0;
    }
    if(root*PAGE_SIZE+(u_int64_t )(1LL<<OFFSET_WIDTH)-1>=RAM_SIZE){
        return 0;
    }

    word_t  temp;
    bool flag_all_sons_empty = true;
    for (uint64_t i=0;i < (uint64_t )(1LL<<OFFSET_WIDTH); i++){
        PMread (root*PAGE_SIZE+i, &temp);
        if(temp != 0 ){
            flag_all_sons_empty = false;
            uint64_t new_root = (uint64_t )temp;
            uint64_t new_p = (p<<OFFSET_WIDTH) +i;
            uint64_t x = dfs (new_root, curr_father,max_frame_p_case2, page_swapped_in,
                                        max_cyclic_distance, max_frame_father,max_frame_cur, root,new_p,max_p,depth-1);
            if(x)
            {
                return x;
            }
        }
    }
    word_t temp_delete;
    if(flag_all_sons_empty && root != curr_father){
        for(uint64_t j = 0; j<PAGE_SIZE; j++){
            PMread(moving_father*PAGE_SIZE +j,&temp_delete);
            if((uint64_t)temp_delete== root){
                PMwrite (moving_father*PAGE_SIZE +j, 0);
                break;
            }
        }
        return root;
    }
    return 0;
}





uint64_t get_empty_frame (uint64_t root, uint64_t curr_father, uint64_t requested_page){
    uint64_t  max_frame_p_case2 =0;
    uint64_t max_frame_father=0;
    uint64_t max_frame_cur=0;
    uint64_t max_cyclic_distance=0;
    uint64_t p=0;
    uint64_t max_p=0;


    uint64_t  empty_frame_case1 = dfs(root, curr_father, &max_frame_p_case2, requested_page,
            &max_cyclic_distance, &max_frame_father,&max_frame_cur,root , p, &max_p,TABLES_DEPTH);
    if (empty_frame_case1){
       // fprintf(stderr," --- from empty\n");

        return empty_frame_case1;
    }
    if(max_frame_p_case2+1<NUM_FRAMES){
     //   fprintf(stderr," --- from max\n");

        return max_frame_p_case2+1;
    }
  //  fprintf(stderr,"evict page %d from frame: %d \n",max_p, max_frame_cur );
    PMevict(max_frame_cur,max_p);
    word_t to_diconnect ;
    for(uint64_t j = 0; j<PAGE_SIZE; j++){
        PMread (max_frame_father*PAGE_SIZE +j,&to_diconnect);
        if(max_frame_cur ==(uint64_t )to_diconnect)
        {
            PMwrite ( max_frame_father * PAGE_SIZE + j , 0 );
        }
    }
    return max_frame_cur;

}


uint64_t read_write(uint64_t virtualAddress){
    if(virtualAddress>=VIRTUAL_MEMORY_SIZE){
        return -1;
    }
    uint64_t index = get_index (virtualAddress);
    uint64_t page_number = index;
    uint64_t root = 0;
    word_t temp=0;
    int num_of_bits_index = VIRTUAL_ADDRESS_WIDTH-OFFSET_WIDTH;
    uint64_t cur_table = get_left_table (index,num_of_bits_index);
    index = get_remain_table (index,num_of_bits_index);
    if (!(VIRTUAL_ADDRESS_WIDTH%OFFSET_WIDTH)){
        num_of_bits_index-=OFFSET_WIDTH;
    }
    else{
        num_of_bits_index-=VIRTUAL_ADDRESS_WIDTH%OFFSET_WIDTH;
    }
    for (int i = 0;i< TABLES_DEPTH ; i++){
        PMread (root*PAGE_SIZE + cur_table, &temp);
        if( temp== 0){
            uint64_t frame = get_empty_frame (0, root, page_number);
            // fprintf(stderr,"frame: %d \n",frame );
            for(uint64_t j = 0; j<PAGE_SIZE; j++){
                PMwrite (frame*PAGE_SIZE +j, 0);
            }
            PMwrite (root*PAGE_SIZE+cur_table,frame);
            root =frame;
        }
        else{
            //   fprintf(stderr,"temp: %d \n",temp );
            root = temp;
        }
        cur_table = get_left_table (index,num_of_bits_index);
        index = get_remain_table (index,num_of_bits_index);
        num_of_bits_index -= OFFSET_WIDTH;
    }
    PMrestore (root, page_number);
    return root;
    //   fprintf(stderr,"restore page %d from frame: %d \n",page_number, root );
}
int VMread(uint64_t virtualAddress, word_t* value) {
    uint64_t offset = get_offset (virtualAddress);
   uint64_t root = read_write (virtualAddress);
    if(root<0){
        return 0;
    }
    PMread(root*PAGE_SIZE + offset, value);
    return 1;
}

int VMwrite(uint64_t virtualAddress, word_t value) {
    uint64_t offset = get_offset (virtualAddress);
    uint64_t root = read_write (virtualAddress);
    if(root<0){
        return 0;
    }
    PMwrite(root*PAGE_SIZE + offset, value);
    return 1;
}
